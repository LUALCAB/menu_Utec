#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from PyQt4 import QtCore, QtGui, uic
 
# Cargar nuestro archivo .ui
form_class = uic.loadUiType("primerapantalla.ui")[0]
 
class MainWindow(QtGui.QMainWindow, form_class):
	def _init_(self, parent=None):
  		QtGui.QMainWindow.init_(self, parent)
  		self.setupUi(self)
  		self.btnMenu.clicked.connect(self.btnMenuClick)
 	def btnMenuClick(self):
		pass 
 

 
app = QtGui.QApplication(sys.argv)
MyWindow = MainWindow(None)
MyWindow.show()
app.exec_()
